<?php
global $states;

$states['VU'] = array(

    "MALAMPA" => __("Malampa", 'erp'),
    "PENAMA"  => __("Penama", 'erp'),
    "SANMA"   => __("Sanma", 'erp'),
    "SHEFA"   => __("Shefa", 'erp'),
    "TAFEA"   => __("Tafea", 'erp'),
    "TORBA"   => __("Torba", 'erp'),

);
