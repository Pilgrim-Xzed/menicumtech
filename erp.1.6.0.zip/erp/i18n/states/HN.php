<?php
global $states;

$states['HN'] = array(

    "ATLANTIDA"        => __("Atlantida", 'erp'),
    "CHOLUTECA"        => __("Choluteca", 'erp'),
    "COLON"            => __("Colon", 'erp'),
    "COMAYAGUA"        => __("Comayagua", 'erp'),
    "COPAN"            => __("Copan", 'erp'),
    "CORTES"           => __("Cortes", 'erp'),
    "ELPARAISO"        => __("El Paraiso", 'erp'),
    "FRANCISCOMORAZAN" => __("Francisco Morazan", 'erp'),
    "GRACIASADIOS"     => __("Gracias a Dios", 'erp'),
    "INTIBUCA"         => __("Intibuca", 'erp'),
    "ISLASDELABAHIA"   => __("Islas de la Bahia", 'erp'),
    "LAPAZ"            => __("La Paz", 'erp'),
    "LEMPIRA"          => __("Lempira", 'erp'),
    "OCOTEPEQUE"       => __("Ocotepeque", 'erp'),
    "OLANCHO"          => __("Olancho", 'erp'),
    "SANTABARBARA"     => __("Santa Barbara", 'erp'),
    "VALLE"            => __("Valle", 'erp'),
    "YORO"             => __("Yoro", 'erp'),

);
