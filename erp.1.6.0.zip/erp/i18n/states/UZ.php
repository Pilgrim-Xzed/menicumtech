<?php
global $states;

$states['UZ'] = array(

    "ANDIJONVILOYATI"              => __("Andijon Viloyati", 'erp'),
    "BUXOROVILOYATI"               => __("Buxoro Viloyati", 'erp'),
    "FARG'ONAVILOYATI"             => __("Farg'ona Viloyati", 'erp'),
    "JIZZAXVILOYATI"               => __("Jizzax Viloyati", 'erp'),
    "NAMANGANVILOYATI"             => __("Namangan Viloyati", 'erp'),
    "NAVOIYVILOYATI"               => __("Navoiy Viloyati", 'erp'),
    "QASHQADARYOVILOYATI"          => __("Qashqadaryo Viloyati", 'erp'),
    "QARAQALPOG'ISTONRESPUBLIKASI" => __("Qaraqalpog'iston Respublikasi", 'erp'),
    "SAMARQANDVILOYATI"            => __("Samarqand Viloyati", 'erp'),
    "SIRDARYOVILOYATI"             => __("Sirdaryo Viloyati", 'erp'),
    "SURXONDARYOVILOYATI"          => __("Surxondaryo Viloyati", 'erp'),
    "TOSHKENTSHAHRI"               => __("Toshkent Shahri", 'erp'),
    "TOSHKENTVILOYATI"             => __("Toshkent Viloyati", 'erp'),
    "XORAZMVILOYATI"               => __("Xorazm Viloyati", 'erp'),

);
