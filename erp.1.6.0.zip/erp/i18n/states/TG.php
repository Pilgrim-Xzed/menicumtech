<?php
global $states;

$states['TG'] = array(

    "KARA"     => __("Kara", 'erp'),
    "PLATEAUX" => __("Plateaux", 'erp'),
    "SAVANES"  => __("Savanes", 'erp'),
    "CENTRALE" => __("Centrale", 'erp'),
    "MARITIME" => __("Maritime", 'erp'),

);
