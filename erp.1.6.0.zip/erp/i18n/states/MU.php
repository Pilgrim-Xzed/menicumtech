<?php
global $states;

$states['MU'] = array(

    "AGALEGAISLANDS"        => __("Agalega Islands", 'erp'),
    "BLACKRIVER"            => __("Black River", 'erp'),
    "CARGADOSCARAJOSSHOALS" => __("Cargados Carajos Shoals", 'erp'),
    "FLACQ"                 => __("Flacq", 'erp'),
    "GRANDPORT"             => __("Grand Port", 'erp'),
    "MOKA"                  => __("Moka", 'erp'),
    "PAMPLEMOUSSES"         => __("Pamplemousses", 'erp'),
    "PLAINESWILHEMS"        => __("Plaines Wilhems", 'erp'),
    "PORTLOUIS"             => __("Port Louis", 'erp'),
    "RIVIEREDUREMPART"      => __("Riviere du Rempart", 'erp'),
    "RODRIGUES"             => __("Rodrigues", 'erp'),
    "SAVANNE"               => __("Savanne", 'erp'),

);
