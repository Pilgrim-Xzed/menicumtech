<?php
global $states;

$states['ZW'] = array(

    "BULAWAYO"           => __("Bulawayo", 'erp'),
    "HARARE"             => __("Harare", 'erp'),
    "MANICALAND"         => __("Manicaland", 'erp'),
    "MASHONALANDCENTRAL" => __("Mashonaland Central", 'erp'),
    "MASHONALANDEAST"    => __("Mashonaland East", 'erp'),
    "MASHONALANDWEST"    => __("Mashonaland West", 'erp'),
    "MASVINGO"           => __("Masvingo", 'erp'),
    "MATABELELANDNORTH"  => __("Matabeleland North", 'erp'),
    "MATABELELANDSOUTH"  => __("Matabeleland South", 'erp'),
    "MIDLANDS"           => __("Midlands", 'erp'),

);
