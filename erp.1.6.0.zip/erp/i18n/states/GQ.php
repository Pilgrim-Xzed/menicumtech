<?php
global $states;

$states['GQ'] = array(

    "ANNOBON"    => __("Annobon", 'erp'),
    "BIOKONORTE" => __("Bioko Norte", 'erp'),
    "BIOKOSUR"   => __("Bioko Sur", 'erp'),
    "CENTROSUR"  => __("Centro Sur", 'erp'),
    "KIE-NTEM"   => __("Kie-Ntem", 'erp'),
    "LITORAL"    => __("Litoral", 'erp'),
    "WELE-NZAS"  => __("Wele-Nzas", 'erp'),

);
