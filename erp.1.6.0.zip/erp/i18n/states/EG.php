<?php
global $states;

$states['EG'] = array(

    "ADDAQAHLIYAH"   => __("Ad Daqahliyah", 'erp'),
    "ALBAHRALAHMAR"  => __("Al Bahr al Ahmar", 'erp'),
    "ALBUHAYRAH"     => __("Al Buhayrah", 'erp'),
    "ALFAYYUM"       => __("Al Fayyum", 'erp'),
    "ALGHARBIYAH"    => __("Al Gharbiyah", 'erp'),
    "ALISKANDARIYAH" => __("Al Iskandariyah", 'erp'),
    "ALISMA'ILIYAH"  => __("Al Isma'iliyah", 'erp'),
    "ALJIZAH"        => __("Al Jizah", 'erp'),
    "ALMINUFIYAH"    => __("Al Minufiyah", 'erp'),
    "ALMINYA"        => __("Al Minya", 'erp'),
    "ALQAHIRAH"      => __("Al Qahirah", 'erp'),
    "ALQALYUBIYAH"   => __("Al Qalyubiyah", 'erp'),
    "ALWADIALJADID"  => __("Al Wadi al Jadid", 'erp'),
    "ASHSHARQIYAH"   => __("Ash Sharqiyah", 'erp'),
    "ASSUWAYS"       => __("As Suways", 'erp'),
    "ASWAN"          => __("Aswan", 'erp'),
    "ASYUT"          => __("Asyut", 'erp'),
    "BANISUWAYF"     => __("Bani Suwayf", 'erp'),
    "BURSA'ID"       => __("Bur Sa'id", 'erp'),
    "DUMYAT"         => __("Dumyat", 'erp'),
    "JANUBSINA'"     => __("Janub Sina'", 'erp'),
    "KAFRASHSHAYKH"  => __("Kafr ash Shaykh", 'erp'),
    "MATRUH"         => __("Matruh", 'erp'),
    "QINA"           => __("Qina", 'erp'),
    "SHAMALSINA'"    => __("Shamal Sina'", 'erp'),
    "SUHAJ"          => __("Suhaj", 'erp'),

);
