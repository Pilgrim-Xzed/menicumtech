<?php
global $states;

$states['LB'] = array(

    "BEYROUTH"   => __("Beyrouth", 'erp'),
    "BEQAA"      => __("Beqaa", 'erp'),
    "LIBAN-NORD" => __("Liban-Nord", 'erp'),
    "LIBAN-SUD"  => __("Liban-Sud", 'erp'),
    "MONT-LIBAN" => __("Mont-Liban", 'erp'),
    "NABATIYE"   => __("Nabatiye", 'erp'),

);
