<?php
global $states;

$states['SD'] = array(

    "A'ALIANNIL"         => __("A'ali an Nil", 'erp'),
    "ALBAHRALAHMAR"      => __("Al Bahr al Ahmar", 'erp'),
    "ALBUHAYRAT"         => __("Al Buhayrat", 'erp'),
    "ALJAZIRAH"          => __("Al Jazirah", 'erp'),
    "ALKHARTUM"          => __("Al Khartum", 'erp'),
    "ALQADARIF"          => __("Al Qadarif", 'erp'),
    "ALWAHDAH"           => __("Al Wahdah", 'erp'),
    "ANNILALABYAD"       => __("An Nil al Abyad", 'erp'),
    "ANNILALAZRAQ"       => __("An Nil al Azraq", 'erp'),
    "ASHSHAMALIYAH"      => __("Ash Shamaliyah", 'erp'),
    "BAHRALJABAL"        => __("Bahr al Jabal", 'erp'),
    "GHARBALISTIWA'IYAH" => __("Gharb al Istiwa'iyah", 'erp'),
    "GHARBBAHRALGHAZAL"  => __("Gharb Bahr al Ghazal", 'erp'),
    "GHARBDARFUR"        => __("Gharb Darfur", 'erp'),
    "GHARBKURDUFAN"      => __("Gharb Kurdufan", 'erp'),
    "JANUBDARFUR"        => __("Janub Darfur", 'erp'),
    "JANUBKURDUFAN"      => __("Janub Kurdufan", 'erp'),
    "JUNQALI"            => __("Junqali", 'erp'),
    "KASSALA"            => __("Kassala", 'erp'),
    "NAHRANNIL"          => __("Nahr an Nil", 'erp'),
    "SHAMALBAHRALGHAZAL" => __("Shamal Bahr al Ghazal", 'erp'),
    "SHAMALDARFUR"       => __("Shamal Darfur", 'erp'),
    "SHAMALKURDUFAN"     => __("Shamal Kurdufan", 'erp'),
    "SHARQALISTIWA'IYAH" => __("Sharq al Istiwa'iyah", 'erp'),
    "SINNAR"             => __("Sinnar", 'erp'),
    "WARAB"              => __("Warab", 'erp'),

);
