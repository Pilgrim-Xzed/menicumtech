<?php 
global $states; 

$states['BZ'] = array(

    "BELIZE"     => __("Belize", 'erp'),
    "CAYO"       => __("Cayo", 'erp'),
    "COROZAL"    => __("Corozal", 'erp'),
    "ORANGEWALK" => __("Orange Walk", 'erp'),
    "STANNCREEK" => __("Stann Creek", 'erp'),
    "TOLEDO"     => __("Toledo", 'erp'),

);
