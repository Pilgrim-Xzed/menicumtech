<?php 
global $states; 

$states['AL'] = array(

    "BERAT"       => __("Berat", 'erp'),
    "DIBRES"      => __("Dibres", 'erp'),
    "DURRES"      => __("Durres", 'erp'),
    "ELBASAN"     => __("Elbasan", 'erp'),
    "FIER"        => __("Fier", 'erp'),
    "GJIROKASTRE" => __("Gjirokastre", 'erp'),
    "KORCE"       => __("Korce", 'erp'),
    "KUKES"       => __("Kukes", 'erp'),
    "LEZHE"       => __("Lezhe", 'erp'),
    "SHKODER"     => __("Shkoder", 'erp'),
    "TIRANE"      => __("Tirane", 'erp'),
    "VLORE"       => __("Vlore", 'erp'),

);
