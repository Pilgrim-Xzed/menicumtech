<?php
global $states;

$states['PY'] = array(

    "ALTOPARAGUAY"    => __("Alto Paraguay", 'erp'),
    "ALTOPARANA"      => __("Alto Parana", 'erp'),
    "AMAMBAY"         => __("Amambay", 'erp'),
    "ASUNCION"        => __("Asuncion", 'erp'),
    "BOQUERON"        => __("Boqueron", 'erp'),
    "CAAGUAZU"        => __("Caaguazu", 'erp'),
    "CAAZAPA"         => __("Caazapa", 'erp'),
    "CANINDEYU"       => __("Canindeyu", 'erp'),
    "CENTRAL"         => __("Central", 'erp'),
    "CONCEPCION"      => __("Concepcion", 'erp'),
    "CORDILLERA"      => __("Cordillera", 'erp'),
    "GUAIRA"          => __("Guaira", 'erp'),
    "ITAPUA"          => __("Itapua", 'erp'),
    "MISIONES"        => __("Misiones", 'erp'),
    "NEEMBUCU"        => __("Neembucu", 'erp'),
    "PARAGUARI"       => __("Paraguari", 'erp'),
    "PRESIDENTEHAYES" => __("Presidente Hayes", 'erp'),
    "SANPEDRO"        => __("San Pedro", 'erp'),

);
