<?php
global $states;

$states['LI'] = array(

    "BALZERS"      => __("Balzers", 'erp'),
    "ESCHEN"       => __("Eschen", 'erp'),
    "GAMPRIN"      => __("Gamprin", 'erp'),
    "MAUREN"       => __("Mauren", 'erp'),
    "PLANKEN"      => __("Planken", 'erp'),
    "RUGGELL"      => __("Ruggell", 'erp'),
    "SCHAAN"       => __("Schaan", 'erp'),
    "SCHELLENBERG" => __("Schellenberg", 'erp'),
    "TRIESEN"      => __("Triesen", 'erp'),
    "TRIESENBERG"  => __("Triesenberg", 'erp'),
    "VADUZ"        => __("Vaduz", 'erp'),

);
