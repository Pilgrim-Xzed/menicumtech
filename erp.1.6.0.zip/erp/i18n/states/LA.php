<?php
global $states;

$states['LA'] = array(

    "ATTAPU"         => __("Attapu", 'erp'),
    "BOKEO"          => __("Bokeo", 'erp'),
    "BOLIKHAMXAI"    => __("Bolikhamxai", 'erp'),
    "CHAMPASAK"      => __("Champasak", 'erp'),
    "HOUAPHAN"       => __("Houaphan", 'erp'),
    "KHAMMOUAN"      => __("Khammouan", 'erp'),
    "LOUANGNAMTHA"   => __("Louangnamtha", 'erp'),
    "LOUANGPHRABANG" => __("Louangphrabang", 'erp'),
    "OUDOMXAI"       => __("Oudomxai", 'erp'),
    "PHONGSALI"      => __("Phongsali", 'erp'),
    "SALAVAN"        => __("Salavan", 'erp'),
    "SAVANNAKHET"    => __("Savannakhet", 'erp'),
    "VIANGCHAN"      => __("Viangchan", 'erp'),
    "VIANGCHAN"      => __("Viangchan", 'erp'),
    "XAIGNABOULI"    => __("Xaignabouli", 'erp'),
    "XAISOMBOUN"     => __("Xaisomboun", 'erp'),
    "XEKONG"         => __("Xekong", 'erp'),
    "XIANGKHOANG"    => __("Xiangkhoang", 'erp'),

);
