<?php
global $states;

$states['HR'] = array(

    "BJELOVARSKO-BILOGORSKA" => __("Bjelovarsko-Bilogorska", 'erp'),
    "BRODSKO-POSAVSKA"       => __("Brodsko-Posavska", 'erp'),
    "DUBROVACKO-NERETVANSKA" => __("Dubrovacko-Neretvanska", 'erp'),
    "ISTARSKA"               => __("Istarska", 'erp'),
    "KARLOVACKA"             => __("Karlovacka", 'erp'),
    "KOPRIVNICKO-KRIZEVACKA" => __("Koprivnicko-Krizevacka", 'erp'),
    "KRAPINSKO-ZAGORSKA"     => __("Krapinsko-Zagorska", 'erp'),
    "LICKO-SENJSKA"          => __("Licko-Senjska", 'erp'),
    "MEDIMURSKA"             => __("Medimurska", 'erp'),
    "OSJECKO-BARANJSKA"      => __("Osjecko-Baranjska", 'erp'),
    "POZESKO-SLAVONSKA"      => __("Pozesko-Slavonska", 'erp'),
    "PRIMORSKO-GORANSKA"     => __("Primorsko-Goranska", 'erp'),
    "SIBENSKO-KNINSKA"       => __("Sibensko-Kninska", 'erp'),
    "SISACKO-MOSLAVACKA"     => __("Sisacko-Moslavacka", 'erp'),
    "SPLITSKO-DALMATINSKA"   => __("Splitsko-Dalmatinska", 'erp'),
    "VARAZDINSKA"            => __("Varazdinska", 'erp'),
    "VIROVITICKO-PODRAVSKA"  => __("Viroviticko-Podravska", 'erp'),
    "VUKOVARSKO-SRIJEMSKA"   => __("Vukovarsko-Srijemska", 'erp'),
    "ZADARSKA"               => __("Zadarska", 'erp'),
    "ZAGREB"                 => __("Zagreb", 'erp'),
    "ZAGREBACKA"             => __("Zagrebacka", 'erp'),

);
