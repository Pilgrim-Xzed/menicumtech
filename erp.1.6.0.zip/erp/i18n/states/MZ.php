<?php
global $states;

$states['MZ'] = array(

    "CABODELGADO"    => __("Cabo Delgado", 'erp'),
    "GAZA"           => __("Gaza", 'erp'),
    "INHAMBANE"      => __("Inhambane", 'erp'),
    "MANICA"         => __("Manica", 'erp'),
    "MAPUTO"         => __("Maputo", 'erp'),
    "CIDADEDEMAPUTO" => __("Cidade de Maputo", 'erp'),
    "NAMPULA"        => __("Nampula", 'erp'),
    "NIASSA"         => __("Niassa", 'erp'),
    "SOFALA"         => __("Sofala", 'erp'),
    "TETE"           => __("Tete", 'erp'),
    "ZAMBEZIA"       => __("Zambezia", 'erp'),

);
