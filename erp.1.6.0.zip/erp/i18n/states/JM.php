<?php
global $states;

$states['JM'] = array(

    "CLARENDON"      => __("Clarendon", 'erp'),
    "HANOVER"        => __("Hanover", 'erp'),
    "KINGSTON"       => __("Kingston", 'erp'),
    "MANCHESTER"     => __("Manchester", 'erp'),
    "PORTLAND"       => __("Portland", 'erp'),
    "SAINTANDREW"    => __("Saint Andrew", 'erp'),
    "SAINTANN"       => __("Saint Ann", 'erp'),
    "SAINTCATHERINE" => __("Saint Catherine", 'erp'),
    "SAINTELIZABETH" => __("Saint Elizabeth", 'erp'),
    "SAINTJAMES"     => __("Saint James", 'erp'),
    "SAINTMARY"      => __("Saint Mary", 'erp'),
    "SAINTTHOMAS"    => __("Saint Thomas", 'erp'),
    "TRELAWNY"       => __("Trelawny", 'erp'),
    "WESTMORELAND"   => __("Westmoreland", 'erp'),

);
