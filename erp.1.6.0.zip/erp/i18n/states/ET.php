<?php
global $states;

$states['ET'] = array(

    "ADDISABABA"                                     => __("Addis Ababa", 'erp'),
    "AFAR"                                           => __("Afar", 'erp'),
    "AMHARA"                                         => __("Amhara", 'erp'),
    "BINSHANGULGUMUZ"                                => __("Binshangul Gumuz", 'erp'),
    "DIREDAWA"                                       => __("Dire Dawa", 'erp'),
    "GAMBELAHIZBOCH"                                 => __("Gambela Hizboch", 'erp'),
    "HARARI"                                         => __("Harari", 'erp'),
    "OROMIA"                                         => __("Oromia", 'erp'),
    "SOMALI"                                         => __("Somali", 'erp'),
    "TIGRAY"                                         => __("Tigray", 'erp'),
    "SOUTHERNNATIONS,NATIONALITIES,ANDPEOPLESREGION" => __("Southern Nations, Nationalities, and Peoples Region", 'erp'),

);
