<?php
global $states;

$states['MW'] = array(

    "BALAKA"     => __("Balaka", 'erp'),
    "BLANTYRE"   => __("Blantyre", 'erp'),
    "CHIKWAWA"   => __("Chikwawa", 'erp'),
    "CHIRADZULU" => __("Chiradzulu", 'erp'),
    "CHITIPA"    => __("Chitipa", 'erp'),
    "DEDZA"      => __("Dedza", 'erp'),
    "DOWA"       => __("Dowa", 'erp'),
    "KARONGA"    => __("Karonga", 'erp'),
    "KASUNGU"    => __("Kasungu", 'erp'),
    "LIKOMA"     => __("Likoma", 'erp'),
    "LILONGWE"   => __("Lilongwe", 'erp'),
    "MACHINGA"   => __("Machinga", 'erp'),
    "MANGOCHI"   => __("Mangochi", 'erp'),
    "MCHINJI"    => __("Mchinji", 'erp'),
    "MULANJE"    => __("Mulanje", 'erp'),
    "MWANZA"     => __("Mwanza", 'erp'),
    "MZIMBA"     => __("Mzimba", 'erp'),
    "NTCHEU"     => __("Ntcheu", 'erp'),
    "NKHATABAY"  => __("Nkhata Bay", 'erp'),
    "NKHOTAKOTA" => __("Nkhotakota", 'erp'),
    "NSANJE"     => __("Nsanje", 'erp'),
    "NTCHISI"    => __("Ntchisi", 'erp'),
    "PHALOMBE"   => __("Phalombe", 'erp'),
    "RUMPHI"     => __("Rumphi", 'erp'),
    "SALIMA"     => __("Salima", 'erp'),
    "THYOLO"     => __("Thyolo", 'erp'),
    "ZOMBA"      => __("Zomba", 'erp'),

);
