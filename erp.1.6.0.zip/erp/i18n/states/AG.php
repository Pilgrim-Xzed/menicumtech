<?php 
global $states; 

$states['AG'] = array(

    "BARBUDA"     => __("Barbuda", 'erp'),
    "REDONDA"     => __("Redonda", 'erp'),
    "SAINTGEORGE" => __("Saint George", 'erp'),
    "SAINTJOHN"   => __("Saint John", 'erp'),
    "SAINTMARY"   => __("Saint Mary", 'erp'),
    "SAINTPAUL"   => __("Saint Paul", 'erp'),
    "SAINTPETER"  => __("Saint Peter", 'erp'),
    "SAINTPHILIP" => __("Saint Philip", 'erp'),

);
