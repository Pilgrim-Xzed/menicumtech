<?php 
global $states; 

$states['BO'] = array(

    "CHUQUISACA" => __("Chuquisaca", 'erp'),
    "COCHABAMBA" => __("Cochabamba", 'erp'),
    "BENI"       => __("Beni", 'erp'),
    "LAPAZ"      => __("La Paz", 'erp'),
    "ORURO"      => __("Oruro", 'erp'),
    "PANDO"      => __("Pando", 'erp'),
    "POTOSI"     => __("Potosi", 'erp'),
    "SANTACRUZ"  => __("Santa Cruz", 'erp'),
    "TARIJA"     => __("Tarija", 'erp'),

);
