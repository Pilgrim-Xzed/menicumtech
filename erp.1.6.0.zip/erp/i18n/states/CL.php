<?php 
global $states; 

$states['CL'] = array(

"AYSEN" => __( "Aysen", 'erp' ),
"ANTOFAGASTA" => __( "Antofagasta", 'erp' ),
"ARAUCANIA" => __( "Araucania", 'erp' ),
"ATACAMA" => __( "Atacama", 'erp' ),
"BIO-BIO" => __( "Bio-Bio", 'erp' ),
"COQUIMBO" => __( "Coquimbo", 'erp' ),
"O'HIGGINS" => __( "O'Higgins", 'erp' ),
"LOSLAGOS" => __( "Los Lagos", 'erp' ),
"MAGALLANESYLAANTARTICACHILENA" => __( "Magallanes y la Antartica Chilena", 'erp' ),
"MAULE" => __( "Maule", 'erp' ),
"SANTIAGOREGIONMETROPOLITANA" => __( "Santiago Region Metropolitana", 'erp' ),
"TARAPACA" => __( "Tarapaca", 'erp' ),
"VALPARAISO" => __( "Valparaiso", 'erp' ),

);