<?php
global $states;

$states['KW'] = array(

    "ALAHMADI"         => __("Al Ahmadi", 'erp'),
    "ALFARWANIYAH"     => __("Al Farwaniyah", 'erp'),
    "ALASIMAH"         => __("Al Asimah", 'erp'),
    "ALJAHRA"          => __("Al Jahra", 'erp'),
    "HAWALLI"          => __("Hawalli", 'erp'),
    "MUBARAKAL-KABEER" => __("Mubarak Al-Kabeer", 'erp'),

);
