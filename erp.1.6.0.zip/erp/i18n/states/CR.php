<?php
global $states;

$states['CR'] = array(

    "ALAJUELA"   => __("Alajuela", 'erp'),
    "CARTAGO"    => __("Cartago", 'erp'),
    "GUANACASTE" => __("Guanacaste", 'erp'),
    "HEREDIA"    => __("Heredia", 'erp'),
    "LIMON"      => __("Limon", 'erp'),
    "PUNTARENAS" => __("Puntarenas", 'erp'),
    "SANJOSE"    => __("San Jose", 'erp'),

);
