<?php 
global $states; 

$states['CM'] = array(

    "ADAMAOUA"     => __("Adamaoua", 'erp'),
    "CENTRE"       => __("Centre", 'erp'),
    "EST"          => __("Est", 'erp'),
    "EXTREME-NORD" => __("Extreme-Nord", 'erp'),
    "LITTORAL"     => __("Littoral", 'erp'),
    "NORD"         => __("Nord", 'erp'),
    "NORD-OUEST"   => __("Nord-Ouest", 'erp'),
    "OUEST"        => __("Ouest", 'erp'),
    "SUD"          => __("Sud", 'erp'),
    "SUD-OUEST"    => __("Sud-Ouest", 'erp'),

);
