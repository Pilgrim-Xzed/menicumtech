<?php
global $states;

$states['SZ'] = array(

    "HHOHHO"     => __("Hhohho", 'erp'),
    "LUBOMBO"    => __("Lubombo", 'erp'),
    "MANZINI"    => __("Manzini", 'erp'),
    "SHISELWENI" => __("Shiselweni", 'erp'),

);
