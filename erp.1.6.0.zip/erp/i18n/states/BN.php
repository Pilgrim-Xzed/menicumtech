<?php 
global $states; 

$states['BN'] = array(

    "BELAIT"         => __("Belait", 'erp'),
    "BRUNEIANDMUARA" => __("Brunei and Muara", 'erp'),
    "TEMBURONG"      => __("Temburong", 'erp'),
    "TUTONG"         => __("Tutong", 'erp'),

);
