<?php
global $states;

$states['IQ'] = array(

    "ALANBAR"        => __("Al Anbar", 'erp'),
    "ALBASRAH"       => __("Al Basrah", 'erp'),
    "ALMUTHANNA"     => __("Al Muthanna", 'erp'),
    "ALQADISIYAH"    => __("Al Qadisiyah", 'erp'),
    "ANNAJAF"        => __("An Najaf", 'erp'),
    "ARBIL"          => __("Arbil", 'erp'),
    "ASSULAYMANIYAH" => __("As Sulaymaniyah", 'erp'),
    "ATTA'MIM"       => __("At Ta'mim", 'erp'),
    "BABIL"          => __("Babil", 'erp'),
    "BAGHDAD"        => __("Baghdad", 'erp'),
    "DAHUK"          => __("Dahuk", 'erp'),
    "DHIQAR"         => __("Dhi Qar", 'erp'),
    "DIYALA"         => __("Diyala", 'erp'),
    "KARBALA'"       => __("Karbala'", 'erp'),
    "MAYSAN"         => __("Maysan", 'erp'),
    "NINAWA"         => __("Ninawa", 'erp'),
    "SALAHADDIN"     => __("Salah ad Din", 'erp'),
    "WASIT"          => __("Wasit", 'erp'),

);
