<?php
global $states;

$states['TD'] = array(

    "BATHA"                 => __("Batha", 'erp'),
    "BILTINE"               => __("Biltine", 'erp'),
    "BORKOU-ENNEDI-TIBESTI" => __("Borkou-Ennedi-Tibesti", 'erp'),
    "CHARI-BAGUIRMI"        => __("Chari-Baguirmi", 'erp'),
    "GUéRA"                 => __("Guéra", 'erp'),
    "KANEM"                 => __("Kanem", 'erp'),
    "LAC"                   => __("Lac", 'erp'),
    "LOGONEOCCIDENTAL"      => __("Logone Occidental", 'erp'),
    "LOGONEORIENTAL"        => __("Logone Oriental", 'erp'),
    "MAYO-KEBBI"            => __("Mayo-Kebbi", 'erp'),
    "MOYEN-CHARI"           => __("Moyen-Chari", 'erp'),
    "OUADDAï"               => __("Ouaddaï", 'erp'),
    "SALAMAT"               => __("Salamat", 'erp'),
    "TANDJILE"              => __("Tandjile", 'erp'),

);
