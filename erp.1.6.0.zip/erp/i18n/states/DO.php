<?php
global $states;

$states['DO'] = array(

    "AZUA"                 => __("Azua", 'erp'),
    "BAORUCO"              => __("Baoruco", 'erp'),
    "BARAHONA"             => __("Barahona", 'erp'),
    "DAJABON"              => __("Dajabon", 'erp'),
    "DISTRITONACIONAL"     => __("Distrito Nacional", 'erp'),
    "DUARTE"               => __("Duarte", 'erp'),
    "ELIASPINA"            => __("Elias Pina", 'erp'),
    "ELSEIBO"              => __("El Seibo", 'erp'),
    "ESPAILLAT"            => __("Espaillat", 'erp'),
    "HATOMAYOR"            => __("Hato Mayor", 'erp'),
    "INDEPENDENCIA"        => __("Independencia", 'erp'),
    "LAALTAGRACIA"         => __("La Altagracia", 'erp'),
    "LAROMANA"             => __("La Romana", 'erp'),
    "LAVEGA"               => __("La Vega", 'erp'),
    "MARIATRINIDADSANCHEZ" => __("Maria Trinidad Sanchez", 'erp'),
    "MONSENORNOUEL"        => __("Monsenor Nouel", 'erp'),
    "MONTECRISTI"          => __("Monte Cristi", 'erp'),
    "MONTEPLATA"           => __("Monte Plata", 'erp'),
    "PEDERNALES"           => __("Pedernales", 'erp'),
    "PERAVIA"              => __("Peravia", 'erp'),
    "PUERTOPLATA"          => __("Puerto Plata", 'erp'),
    "SALCEDO"              => __("Salcedo", 'erp'),
    "SAMANA"               => __("Samana", 'erp'),
    "SANCHEZRAMIREZ"       => __("Sanchez Ramirez", 'erp'),
    "SANCRISTOBAL"         => __("San Cristobal", 'erp'),
    "SANJOSEDEOCOA"        => __("San Jose de Ocoa", 'erp'),
    "SANJUAN"              => __("San Juan", 'erp'),
    "SANPEDRODEMACORIS"    => __("San Pedro de Macoris", 'erp'),
    "SANTIAGO"             => __("Santiago", 'erp'),
    "SANTIAGORODRIGUEZ"    => __("Santiago Rodriguez", 'erp'),
    "SANTODOMINGO"         => __("Santo Domingo", 'erp'),
    "VALVERDE"             => __("Valverde", 'erp'),

);
