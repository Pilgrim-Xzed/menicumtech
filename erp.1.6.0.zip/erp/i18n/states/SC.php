<?php
global $states;

$states['SC'] = array(

    "ANSEAUXPINS"       => __("Anse aux Pins", 'erp'),
    "ANSEBOILEAU"       => __("Anse Boileau", 'erp'),
    "ANSEETOILE"        => __("Anse Etoile", 'erp'),
    "ANSELOUIS"         => __("Anse Louis", 'erp'),
    "ANSEROYALE"        => __("Anse Royale", 'erp'),
    "BAIELAZARE"        => __("Baie Lazare", 'erp'),
    "BAIESAINTEANNE"    => __("Baie Sainte Anne", 'erp'),
    "BEAUVALLON"        => __("Beau Vallon", 'erp'),
    "BELAIR"            => __("Bel Air", 'erp'),
    "BELOMBRE"          => __("Bel Ombre", 'erp'),
    "CASCADE"           => __("Cascade", 'erp'),
    "GLACIS"            => __("Glacis", 'erp'),
    "GRAND'ANSE"        => __("Grand' Anse", 'erp'),
    "GRAND'ANSE"        => __("Grand' Anse", 'erp'),
    "LADIGUE"           => __("La Digue", 'erp'),
    "LARIVIEREANGLAISE" => __("La Riviere Anglaise", 'erp'),
    "MONTBUXTON"        => __("Mont Buxton", 'erp'),
    "MONTFLEURI"        => __("Mont Fleuri", 'erp'),
    "PLAISANCE"         => __("Plaisance", 'erp'),
    "POINTELARUE"       => __("Pointe La Rue", 'erp'),
    "PORTGLAUD"         => __("Port Glaud", 'erp'),
    "SAINTLOUIS"        => __("Saint Louis", 'erp'),
    "TAKAMAKA"          => __("Takamaka", 'erp'),

);
