<?php
global $states;

$states['LU'] = array(

    "DIEKIRCH"     => __("Diekirch", 'erp'),
    "GREVENMACHER" => __("Grevenmacher", 'erp'),
    "LUXEMBOURG"   => __("Luxembourg", 'erp'),

);
