<?php
global $states;

$states['DM'] = array(

    "SAINTANDREW"  => __("Saint Andrew", 'erp'),
    "SAINTDAVID"   => __("Saint David", 'erp'),
    "SAINTGEORGE"  => __("Saint George", 'erp'),
    "SAINTJOHN"    => __("Saint John", 'erp'),
    "SAINTJOSEPH"  => __("Saint Joseph", 'erp'),
    "SAINTLUKE"    => __("Saint Luke", 'erp'),
    "SAINTMARK"    => __("Saint Mark", 'erp'),
    "SAINTPATRICK" => __("Saint Patrick", 'erp'),
    "SAINTPAUL"    => __("Saint Paul", 'erp'),
    "SAINTPETER"   => __("Saint Peter", 'erp'),

);
