<?php
global $states;

$states['KM'] = array(

    "GRANDECOMORE(NJAZIDJA)" => __("Grande Comore (Njazidja)", 'erp'),
    "ANJOUAN(NZWANI)"        => __("Anjouan (Nzwani)", 'erp'),
    "MOHELI(MWALI)"          => __("Moheli (Mwali)", 'erp'),

);
