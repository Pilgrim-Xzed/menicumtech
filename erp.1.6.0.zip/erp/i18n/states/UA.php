<?php
global $states;

$states['UA'] = array(

    "CHERKASY"         => __("Cherkasy", 'erp'),
    "CHERNIHIV"        => __("Chernihiv", 'erp'),
    "CHERNIVTSI"       => __("Chernivtsi", 'erp'),
    "CRIMEA"           => __("Crimea", 'erp'),
    "DNIPROPETROVS'K"  => __("Dnipropetrovs'k", 'erp'),
    "DONETS'K"         => __("Donets'k", 'erp'),
    "IVANO-FRANKIVS'K" => __("Ivano-Frankivs'k", 'erp'),
    "KHARKIV"          => __("Kharkiv", 'erp'),
    "KHERSON"          => __("Kherson", 'erp'),
    "KHMEL'NYTS'KYY"   => __("Khmel'nyts'kyy", 'erp'),
    "KIROVOHRAD"       => __("Kirovohrad", 'erp'),
    "KIEV"             => __("Kiev", 'erp'),
    "KYYIV"            => __("Kyyiv", 'erp'),
    "LUHANS'K"         => __("Luhans'k", 'erp'),
    "L'VIV"            => __("L'viv", 'erp'),
    "MYKOLAYIV"        => __("Mykolayiv", 'erp'),
    "ODESA"            => __("Odesa", 'erp'),
    "POLTAVA"          => __("Poltava", 'erp'),
    "RIVNE"            => __("Rivne", 'erp'),
    "SEVASTOPOL'"      => __("Sevastopol'", 'erp'),
    "SUMY"             => __("Sumy", 'erp'),
    "TERNOPIL'"        => __("Ternopil'", 'erp'),
    "VINNYTSYA"        => __("Vinnytsya", 'erp'),
    "VOLYN'"           => __("Volyn'", 'erp'),
    "ZAKARPATTYA"      => __("Zakarpattya", 'erp'),
    "ZAPORIZHZHYA"     => __("Zaporizhzhya", 'erp'),
    "ZHYTOMYR"         => __("Zhytomyr", 'erp'),

);
