<?php
global $states;

$states['UY'] = array(

    "ARTIGAS"      => __("Artigas", 'erp'),
    "CANELONES"    => __("Canelones", 'erp'),
    "CERROLARGO"   => __("Cerro Largo", 'erp'),
    "COLONIA"      => __("Colonia", 'erp'),
    "DURAZNO"      => __("Durazno", 'erp'),
    "FLORES"       => __("Flores", 'erp'),
    "FLORIDA"      => __("Florida", 'erp'),
    "LAVALLEJA"    => __("Lavalleja", 'erp'),
    "MALDONADO"    => __("Maldonado", 'erp'),
    "MONTEVIDEO"   => __("Montevideo", 'erp'),
    "PAYSANDU"     => __("Paysandu", 'erp'),
    "RIONEGRO"     => __("Rio Negro", 'erp'),
    "RIVERA"       => __("Rivera", 'erp'),
    "ROCHA"        => __("Rocha", 'erp'),
    "SALTO"        => __("Salto", 'erp'),
    "SANJOSE"      => __("San Jose", 'erp'),
    "SORIANO"      => __("Soriano", 'erp'),
    "TACUAREMBO"   => __("Tacuarembo", 'erp'),
    "TREINTAYTRES" => __("Treinta y Tres", 'erp'),

);
