<?php
global $states;

$states['MN'] = array(

    "ARHANGAY"    => __("Arhangay", 'erp'),
    "BAYANHONGOR" => __("Bayanhongor", 'erp'),
    "BAYAN-OLGIY" => __("Bayan-Olgiy", 'erp'),
    "BULGAN"      => __("Bulgan", 'erp'),
    "DARHANUUL"   => __("Darhan Uul", 'erp'),
    "DORNOD"      => __("Dornod", 'erp'),
    "DORNOGOVI"   => __("Dornogovi", 'erp'),
    "DUNDGOVI"    => __("Dundgovi", 'erp'),
    "DZAVHAN"     => __("Dzavhan", 'erp'),
    "GOVI-ALTAY"  => __("Govi-Altay", 'erp'),
    "GOVI-SUMBER" => __("Govi-Sumber", 'erp'),
    "HENTIY"      => __("Hentiy", 'erp'),
    "HOVD"        => __("Hovd", 'erp'),
    "HOVSGOL"     => __("Hovsgol", 'erp'),
    "OMNOGOVI"    => __("Omnogovi", 'erp'),
    "ORHON"       => __("Orhon", 'erp'),
    "OVORHANGAY"  => __("Ovorhangay", 'erp'),
    "SELENGE"     => __("Selenge", 'erp'),
    "SUHBAATAR"   => __("Suhbaatar", 'erp'),
    "TOV"         => __("Tov", 'erp'),
    "ULAANBAATAR" => __("Ulaanbaatar", 'erp'),
    "UVS"         => __("Uvs", 'erp'),

);
