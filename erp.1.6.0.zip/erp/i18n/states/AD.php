<?php 
global $states; 

$states['AD'] = array(

    "ANDORRALAVELLA"     => __("Andorra la Vella", 'erp'),
    "CANILLO"            => __("Canillo", 'erp'),
    "ENCAMP"             => __("Encamp", 'erp'),
    "ESCALDES-ENGORDANY" => __("Escaldes-Engordany", 'erp'),
    "LAMASSANA"          => __("La Massana", 'erp'),
    "ORDINO"             => __("Ordino", 'erp'),
    "SANTJULIADELORIA"   => __("Sant Julia de Loria", 'erp'),

);
