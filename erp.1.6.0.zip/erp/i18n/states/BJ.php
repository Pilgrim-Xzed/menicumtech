<?php 
global $states; 

$states['BJ'] = array(

    "ALIBORI"    => __("Alibori", 'erp'),
    "ATAKORA"    => __("Atakora", 'erp'),
    "ATLANTIQUE" => __("Atlantique", 'erp'),
    "BORGOU"     => __("Borgou", 'erp'),
    "COLLINES"   => __("Collines", 'erp'),
    "DONGA"      => __("Donga", 'erp'),
    "KOUFFO"     => __("Kouffo", 'erp'),
    "LITTORAL"   => __("Littoral", 'erp'),
    "MONO"       => __("Mono", 'erp'),
    "OUEME"      => __("Oueme", 'erp'),
    "PLATEAU"    => __("Plateau", 'erp'),
    "ZOU"        => __("Zou", 'erp'),

);
