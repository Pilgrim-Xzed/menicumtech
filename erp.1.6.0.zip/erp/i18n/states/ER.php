<?php
global $states;

$states['ER'] = array(

    "ANSEBA"              => __("Anseba", 'erp'),
    "DEBUB"               => __("Debub", 'erp'),
    "DEBUBAWIK'EYIHBAHRI" => __("Debubawi K'eyih Bahri", 'erp'),
    "GASHBARKA"           => __("Gash Barka", 'erp'),
    "MA'AKEL"             => __("Ma'akel", 'erp'),
    "SEMENAWIKEYIHBAHRI"  => __("Semenawi Keyih Bahri", 'erp'),

);
