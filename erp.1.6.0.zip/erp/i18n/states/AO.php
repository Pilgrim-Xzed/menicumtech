<?php 
global $states; 

$states['AO'] = array(

    "BENGO"         => __("Bengo", 'erp'),
    "BENGUELA"      => __("Benguela", 'erp'),
    "BIE"           => __("Bie", 'erp'),
    "CABINDA"       => __("Cabinda", 'erp'),
    "CUANDOCUBANGO" => __("Cuando Cubango", 'erp'),
    "CUANZANORTE"   => __("Cuanza Norte", 'erp'),
    "CUANZASUL"     => __("Cuanza Sul", 'erp'),
    "CUNENE"        => __("Cunene", 'erp'),
    "HUAMBO"        => __("Huambo", 'erp'),
    "HUILA"         => __("Huila", 'erp'),
    "LUANDA"        => __("Luanda", 'erp'),
    "LUNDANORTE"    => __("Lunda Norte", 'erp'),
    "LUNDASUL"      => __("Lunda Sul", 'erp'),
    "MALANJE"       => __("Malanje", 'erp'),
    "MOXICO"        => __("Moxico", 'erp'),
    "NAMIBE"        => __("Namibe", 'erp'),
    "UIGE"          => __("Uige", 'erp'),
    "ZAIRE"         => __("Zaire", 'erp'),

);
