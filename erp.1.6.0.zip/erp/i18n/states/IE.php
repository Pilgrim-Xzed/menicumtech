<?php
global $states;

$states['IE'] = array(

    "CARLOW"    => __("Carlow", 'erp'),
    "CAVAN"     => __("Cavan", 'erp'),
    "CLARE"     => __("Clare", 'erp'),
    "CORK"      => __("Cork", 'erp'),
    "DONEGAL"   => __("Donegal", 'erp'),
    "DUBLIN"    => __("Dublin", 'erp'),
    "GALWAY"    => __("Galway", 'erp'),
    "KERRY"     => __("Kerry", 'erp'),
    "KILDARE"   => __("Kildare", 'erp'),
    "KILKENNY"  => __("Kilkenny", 'erp'),
    "LAOIS"     => __("Laois", 'erp'),
    "LEITRIM"   => __("Leitrim", 'erp'),
    "LIMERICK"  => __("Limerick", 'erp'),
    "LONGFORD"  => __("Longford", 'erp'),
    "LOUTH"     => __("Louth", 'erp'),
    "MAYO"      => __("Mayo", 'erp'),
    "MEATH"     => __("Meath", 'erp'),
    "MONAGHAN"  => __("Monaghan", 'erp'),
    "OFFALY"    => __("Offaly", 'erp'),
    "ROSCOMMON" => __("Roscommon", 'erp'),
    "SLIGO"     => __("Sligo", 'erp'),
    "TIPPERARY" => __("Tipperary", 'erp'),
    "WATERFORD" => __("Waterford", 'erp'),
    "WESTMEATH" => __("Westmeath", 'erp'),
    "WEXFORD"   => __("Wexford", 'erp'),
    "WICKLOW"   => __("Wicklow", 'erp'),

);
