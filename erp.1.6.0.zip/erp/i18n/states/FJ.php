<?php
global $states;

$states['FJ'] = array(

    "CENTRAL(SUVA)"    => __("Central (Suva)", 'erp'),
    "EASTERN(LEVUKA)"  => __("Eastern (Levuka)", 'erp'),
    "NORTHERN(LABASA)" => __("Northern (Labasa)", 'erp'),
    "ROTUMA"           => __("Rotuma", 'erp'),
    "WESTERN(LAUTOKA)" => __("Western (Lautoka)", 'erp'),

);
