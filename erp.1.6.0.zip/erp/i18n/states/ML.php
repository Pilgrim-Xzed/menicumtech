<?php
global $states;

$states['ML'] = array(

    "BAMAKO(CAPITAL)" => __("Bamako (Capital)", 'erp'),
    "GAO"             => __("Gao", 'erp'),
    "KAYES"           => __("Kayes", 'erp'),
    "KIDAL"           => __("Kidal", 'erp'),
    "KOULIKORO"       => __("Koulikoro", 'erp'),
    "MOPTI"           => __("Mopti", 'erp'),
    "SEGOU"           => __("Segou", 'erp'),
    "SIKASSO"         => __("Sikasso", 'erp'),
    "TOMBOUCTOU"      => __("Tombouctou", 'erp'),

);
