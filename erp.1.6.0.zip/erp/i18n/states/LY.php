<?php
global $states;

$states['LY'] = array(

    "AJDABIYA"        => __("Ajdabiya", 'erp'),
    "AL'AZIZIYAH"     => __("Al 'Aziziyah", 'erp'),
    "ALFATIH"         => __("Al Fatih", 'erp'),
    "ALJABALALAKHDAR" => __("Al Jabal al Akhdar", 'erp'),
    "ALJUFRAH"        => __("Al Jufrah", 'erp'),
    "ALKHUMS"         => __("Al Khums", 'erp'),
    "ALKUFRAH"        => __("Al Kufrah", 'erp'),
    "ANNUQATALKHAMS"  => __("An Nuqat al Khams", 'erp'),
    "ASHSHATI'"       => __("Ash Shati'", 'erp'),
    "AWBARI"          => __("Awbari", 'erp'),
    "AZZAWIYAH"       => __("Az Zawiyah", 'erp'),
    "BANGHAZI"        => __("Banghazi", 'erp'),
    "DARNAH"          => __("Darnah", 'erp'),
    "GHADAMIS"        => __("Ghadamis", 'erp'),
    "GHARYAN"         => __("Gharyan", 'erp'),
    "MISRATAH"        => __("Misratah", 'erp'),
    "MURZUQ"          => __("Murzuq", 'erp'),
    "SABHA"           => __("Sabha", 'erp'),
    "SAWFAJJIN"       => __("Sawfajjin", 'erp'),
    "SURT"            => __("Surt", 'erp'),
    "TARABULUS"       => __("Tarabulus", 'erp'),
    "TARHUNAH"        => __("Tarhunah", 'erp'),
    "TUBRUQ"          => __("Tubruq", 'erp'),
    "YAFRAN"          => __("Yafran", 'erp'),
    "ZLITAN"          => __("Zlitan", 'erp'),

);
