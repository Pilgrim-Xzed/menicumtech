<?php 
global $states; 

$states['BA'] = array(

    "UNA-SANA[FEDERATION]"            => __("Una-Sana [Federation]", 'erp'),
    "POSAVINA[FEDERATION]"            => __("Posavina [Federation]", 'erp'),
    "TUZLA[FEDERATION]"               => __("Tuzla [Federation]", 'erp'),
    "ZENICA-DOBOJ[FEDERATION]"        => __("Zenica-Doboj [Federation]", 'erp'),
    "BOSNIANPODRINJE[FEDERATION]"     => __("Bosnian Podrinje [Federation]", 'erp'),
    "CENTRALBOSNIA[FEDERATION]"       => __("Central Bosnia [Federation]", 'erp'),
    "HERZEGOVINA-NERETVA[FEDERATION]" => __("Herzegovina-Neretva [Federation]", 'erp'),
    "WESTHERZEGOVINA[FEDERATION]"     => __("West Herzegovina [Federation]", 'erp'),
    "SARAJEVO[FEDERATION]"            => __("Sarajevo [Federation]", 'erp'),
    "WESTBOSNIA[FEDERATION]"          => __(" West Bosnia [Federation]", 'erp'),
    "BANJALUKA[RS]"                   => __("Banja Luka [RS]", 'erp'),
    "BIJELJINA[RS]"                   => __("Bijeljina [RS]", 'erp'),
    "DOBOJ[RS]"                       => __("Doboj [RS]", 'erp'),
    "FO?A[RS]"                        => __("Fo?a [RS]", 'erp'),
    "SARAJEVO-ROMANIJA[RS]"           => __("Sarajevo-Romanija [RS]", 'erp'),
    "TREBINJE[RS]"                    => __("Trebinje [RS]", 'erp'),
    "VLASENICA[RS]"                   => __("Vlasenica [RS]", 'erp'),

);
