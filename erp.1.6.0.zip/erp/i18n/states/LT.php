<?php
global $states;

$states['LT'] = array(

    "ALYTAUS"      => __("Alytaus", 'erp'),
    "KAUNO"        => __("Kauno", 'erp'),
    "KLAIPEDOS"    => __("Klaipedos", 'erp'),
    "MARIJAMPOLES" => __("Marijampoles", 'erp'),
    "PANEVEZIO"    => __("Panevezio", 'erp'),
    "SIAULIU"      => __("Siauliu", 'erp'),
    "TAURAGES"     => __("Taurages", 'erp'),
    "TELSIU"       => __("Telsiu", 'erp'),
    "UTENOS"       => __("Utenos", 'erp'),
    "VILNIAUS"     => __("Vilniaus", 'erp'),

);
