<?php
global $states;

$states['CY'] = array(

    "FAMAGUSTA" => __("Famagusta", 'erp'),
    "KYRENIA"   => __("Kyrenia", 'erp'),
    "LARNACA"   => __("Larnaca", 'erp'),
    "LIMASSOL"  => __("Limassol", 'erp'),
    "NICOSIA"   => __("Nicosia", 'erp'),
    "PAPHOS"    => __("Paphos", 'erp'),

);
