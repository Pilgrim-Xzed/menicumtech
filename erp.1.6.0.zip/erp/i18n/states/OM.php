<?php
global $states;

$states['OM'] = array(

    "ADDAKHILIYAH" => __("Ad Dakhiliyah", 'erp'),
    "ALBATINAH"    => __("Al Batinah", 'erp'),
    "ALWUSTA"      => __("Al Wusta", 'erp'),
    "ASHSHARQIYAH" => __("Ash Sharqiyah", 'erp'),
    "AZZAHIRAH"    => __("Az Zahirah", 'erp'),
    "MASQAT"       => __("Masqat", 'erp'),
    "MUSANDAM"     => __("Musandam", 'erp'),
    "DHOFAR"       => __("Dhofar", 'erp'),

);
