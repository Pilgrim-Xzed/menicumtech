<?php 
global $states; 

$states['BW'] = array(

    "CENTRAL"   => __("Central", 'erp'),
    "GHANZI"    => __("Ghanzi", 'erp'),
    "KGALAGADI" => __("Kgalagadi", 'erp'),
    "KGATLENG"  => __("Kgatleng", 'erp'),
    "KWENENG"   => __("Kweneng", 'erp'),
    "NORTHEAST" => __("North East", 'erp'),
    "NORTHWEST" => __("North West", 'erp'),
    "SOUTHEAST" => __("South East", 'erp'),
    "SOUTHERN"  => __("Southern", 'erp'),

);
