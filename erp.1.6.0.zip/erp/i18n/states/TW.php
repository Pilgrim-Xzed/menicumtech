<?php
global $states;

$states['TW'] = array(

    "CHANG-HUA"      => __("Chang-hua", 'erp'),
    "CHIA-I"         => __("Chia-i", 'erp'),
    "HSIN-CHU"       => __("Hsin-chu", 'erp'),
    "HUA-LIEN"       => __("Hua-lien", 'erp'),
    "I-LAN"          => __("I-lan", 'erp'),
    "KAO-HSIUNG"     => __("Kao-hsiung", 'erp'),
    "KIN-MEN"        => __("Kin-men", 'erp'),
    "LIEN-CHIANG"    => __("Lien-chiang", 'erp'),
    "MIAO-LI"        => __("Miao-li", 'erp'),
    "NAN-T'OU"       => __("Nan-t'ou", 'erp'),
    "P'ENG-HU"       => __("P'eng-hu", 'erp'),
    "P'ING-TUNG"     => __("P'ing-tung", 'erp'),
    "T'AI-CHUNG"     => __("T'ai-chung", 'erp'),
    "T'AI-NAN"       => __("T'ai-nan", 'erp'),
    "T'AI-PEI"       => __("T'ai-pei", 'erp'),
    "T'AI-TUNG"      => __("T'ai-tung", 'erp'),
    "T'AO-YUAN"      => __("T'ao-yuan", 'erp'),
    "YUN-LIN"        => __("Yun-lin", 'erp'),
    "CHIA-I"         => __("Chia-i", 'erp'),
    "CHI-LUNG"       => __("Chi-lung", 'erp'),
    "HSIN-CHU"       => __("Hsin-chu", 'erp'),
    "T'AI-CHUNG"     => __("T'ai-chung", 'erp'),
    "T'AI-NAN"       => __("T'ai-nan", 'erp'),
    "KAO-HSIUNGCITY" => __("Kao-hsiung city", 'erp'),
    "T'AI-PEICITY"   => __("T'ai-pei city", 'erp'),

);
