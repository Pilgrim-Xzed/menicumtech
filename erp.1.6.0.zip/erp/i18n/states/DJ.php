<?php
global $states;

$states['DJ'] = array(

    "ALISABIH" => __("Ali Sabih", 'erp'),
    "DIKHIL"   => __("Dikhil", 'erp'),
    "DJIBOUTI" => __("Djibouti", 'erp'),
    "OBOCK"    => __("Obock", 'erp'),
    "TADJOURA" => __("Tadjoura", 'erp'),

);
