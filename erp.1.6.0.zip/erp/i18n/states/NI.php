<?php
global $states;

$states['NI'] = array(

    "ATLANTICONORTE" => __("Atlantico Norte", 'erp'),
    "ATLANTICOSUR"   => __("Atlantico Sur", 'erp'),
    "BOACO"          => __("Boaco", 'erp'),
    "CARAZO"         => __("Carazo", 'erp'),
    "CHINANDEGA"     => __("Chinandega", 'erp'),
    "CHONTALES"      => __("Chontales", 'erp'),
    "ESTELI"         => __("Esteli", 'erp'),
    "GRANADA"        => __("Granada", 'erp'),
    "JINOTEGA"       => __("Jinotega", 'erp'),
    "LEON"           => __("Leon", 'erp'),
    "MADRIZ"         => __("Madriz", 'erp'),
    "MANAGUA"        => __("Managua", 'erp'),
    "MASAYA"         => __("Masaya", 'erp'),
    "MATAGALPA"      => __("Matagalpa", 'erp'),
    "NUEVASEGOVIA"   => __("Nueva Segovia", 'erp'),
    "RIOSANJUAN"     => __("Rio San Juan", 'erp'),
    "RIVAS"          => __("Rivas", 'erp'),

);
