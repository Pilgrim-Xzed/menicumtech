<?php

namespace MailOptin\MailerliteConnect\APIClass\Exceptions;

use Exception;

class MailerLiteSdkException extends Exception {}