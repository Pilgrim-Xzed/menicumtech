<?php

namespace MailOptin\MailerliteConnect\APIClass\Api;

use MailOptin\MailerliteConnect\APIClass\Common\ApiAbstract;

class Fields extends ApiAbstract {

    protected $endpoint = 'fields';

}