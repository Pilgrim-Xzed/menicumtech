<?php

namespace MailOptin\Core\Admin\Customizer\CustomControls;

class WP_Customize_View_Tags_Shortcode_Content extends WP_Customize_Custom_Content
{
    public $type = 'mailoptin_view_tag_shortcode';

    public $no_wrapper_div = true;
}