var mailoptin_no_adblock_detected = true;
