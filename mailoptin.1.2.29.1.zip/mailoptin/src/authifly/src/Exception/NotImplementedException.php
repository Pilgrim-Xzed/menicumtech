<?php
/*!
* Authifly
* https://hybridauth.github.io | https://github.com/mailoptin/authifly
*  (c) 2017 Hybridauth authors | https://hybridauth.github.io/license.html
*/

namespace Authifly\Exception;

/**
 *
 */
class NotImplementedException extends BadMethodCallException implements ExceptionInterface
{
}
