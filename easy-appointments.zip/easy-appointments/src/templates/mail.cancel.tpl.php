<div>
    <p><?php _e('Do you want to Cancel appointment?', 'easy-appointments');?></p>
    <form method="post">
        <input name="confirmed" type="hidden" value="true">
        <button class="button button-primary"><?php _e('Yes, I want to Cancel appointment.', 'easy-appointments');?></button>
    </form>
</div>