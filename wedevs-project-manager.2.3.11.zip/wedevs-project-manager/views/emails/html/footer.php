

		<div style="height: 71px; background: #454545;padding-top: 25px;text-align: center;">
			<a style="text-decoration: none; font-family: arial; text-align: center; font-size: 12px; color: #fff;" href="<?php echo esc_url(home_url()); ?>"><?php echo esc_html(get_bloginfo('name')); ?></a>
		</div>
		</td>
		</tr>
		</table>
	</div>
</div>
