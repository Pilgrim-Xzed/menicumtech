<div class="pmswitchproject pm-global" id="pmswitchproject">
    <div class="pmswitcharea">
        <div class="inner" >
            <div class="pm-sp-in">
                <input id="tags" type="text" placeholder="Jump to a project">
                <div class="pm-spresult"></div>
            </div>
            <div class="switchinfo">
                <div>
                    <span class="icon-pm-navigation"></span> 
                    <span> to navigate</span>
                </div>
                <div>
                    <span class="icon-pm-enter"></span>
                    <span> to select </span>
                </div>
                <div>
                    <span>esc</span>
                    <span>to dismiss</span>
                </div>
            </div>
        </div>
    </div>
    <div class="pmbackoverlay" ></div>
    
</div>

