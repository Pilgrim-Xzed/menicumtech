<?php

namespace WeDevs\PM\Common\Traits;

use WeDevs\PM\Common\Models\Assignee;

trait Assignee_Filter {

    public function assigned_to() {
        var_dump('aslkdjhflaksdjfhasdf'); die();
    }
}
