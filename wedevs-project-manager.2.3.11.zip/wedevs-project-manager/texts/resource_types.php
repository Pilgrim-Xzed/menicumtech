<?php

return [
    'project' => [
        __( 'project', 'wedevs-project-manager' ),
    ],
    'discussion_board' => [
        __( 'discussion board', 'wedevs-project-manager' ),
    ],
    'task_list' => [
        __( 'task list', 'wedevs-project-manager' ),
    ],
    'task' => [
        __( 'task', 'wedevs-project-manager' ),
    ],
    'milestone' => [
        __( 'milestone', 'wedevs-project-manager' ),
    ],
    'comment' => [
        __( 'comment', 'wedevs-project-manager' ),
    ],
    'file' => [
        __( 'file', 'wedevs-project-manager' ),
    ],
];